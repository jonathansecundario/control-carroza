# 🤖 Robot Ojos

App web (PWA) para detectar personas con la cámara del teléfono y mandar comandos de 1 byte por Bluetooth BLE a una ESP32.

## 🚀 Cómo usar

### 1. Subir a GitHub Pages
1. Crear un nuevo repositorio en GitHub
2. Subir todos los archivos de este ZIP
3. Ir a **Settings → Pages → Source → GitHub Actions**
4. El workflow ya está incluido en `.github/workflows/pages.yml`
5. Esperar 1 minuto y listo: `https://TUUSUARIO.github.io/TUREPO/`

### 2. ESP32
1. Abrir `RobotOjos_ESP32.ino` en Arduino IDE
2. Instalar librería **ESP32 BLE Arduino** (by Neil Kolban)
3. Seleccionar placa ESP32 y subir
4. La ESP32 aparece como **"RobotOjos"** en el Bluetooth

### 3. Teléfono
1. Abrir la URL de GitHub Pages en **Chrome Android**
2. Tocar **"Agregar a pantalla de inicio"**
3. Tocar **INICIAR CÁMARA**
4. Tocar **🔗 BLE**, elegir "RobotOjos"
5. Listo. La app detecta personas y manda comandos sola.

## 📡 Comandos (1 byte)

| Letra | Acción |
|-------|--------|
| L | Izquierda |
| C | Centro / Avanzar |
| R | Derecha |
| F | Seguir (Follow) |
| S | Stop |
| X | Perdido |

## ⚡ Características

- **TensorFlow.js COCO-SSD** para detección de personas
- **Solo 1 persona**: la más grande (más cercana)
- **3 zonas**: Izquierda 35% / Centro 30% / Derecha 35%
- **Modo Auto/Manual**
- **Comandos editables** desde la app
- **Envío throttled**: máximo ~6-7 comandos/segundo
- **Funciona offline** después de la primera carga

## 🔌 Pines ESP32 → L298N

| ESP32 | L298N |
|-------|-------|
| GPIO12 | IN1 |
| GPIO14 | IN2 |
| GPIO27 | IN3 |
| GPIO26 | IN4 |
| GPIO25 | ENA |
| GPIO33 | ENB |

## ⚠️ Importante

- **Chrome Android obligatorio**. Web Bluetooth no funciona en Safari, Firefox ni iOS.
- La ESP32 usa **BLE nativo**, no Bluetooth Classic. Si tenés un HC-05/06, sacalo y usá el BLE de la ESP32 directamente.
