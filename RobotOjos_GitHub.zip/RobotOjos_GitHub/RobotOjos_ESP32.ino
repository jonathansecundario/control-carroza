#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>

#define SERVICE_UUID        "6e400001-b5a3-f393-e0a9-e50e24dcca9e"
#define CHARACTERISTIC_UUID "6e400002-b5a3-f393-e0a9-e50e24dcca9e"

#define IN1 12
#define IN2 14
#define IN3 27
#define IN4 26
#define ENA 25
#define ENB 33

int velocidad = 200;
bool deviceConnected = false;
BLECharacteristic *pCharacteristic;

class ServerCB: public BLEServerCallbacks {
  void onConnect(BLEServer* s) { deviceConnected = true; Serial.println("Conectado"); }
  void onDisconnect(BLEServer* s) { deviceConnected = false; Serial.println("Desconectado"); delay(500); s->startAdvertising(); }
};

class CharCB: public BLECharacteristicCallbacks {
  void onWrite(BLECharacteristic *c) {
    std::string v = c->getValue();
    if (v.length() > 0) { Serial.print("CMD: "); Serial.println(v[0]); procesar(v[0]); }
  }
};

void setup() {
  Serial.begin(115200);
  pinMode(IN1, OUTPUT); pinMode(IN2, OUTPUT); pinMode(IN3, OUTPUT); pinMode(IN4, OUTPUT);
  pinMode(ENA, OUTPUT); pinMode(ENB, OUTPUT); detener();

  BLEDevice::init("RobotOjos");
  BLEServer *s = BLEDevice::createServer(); s->setCallbacks(new ServerCB());
  BLEService *svc = s->createService(SERVICE_UUID);
  pCharacteristic = svc->createCharacteristic(CHR, BLECharacteristic::PROPERTY_WRITE | BLECharacteristic::PROPERTY_WRITE_NR);
  pCharacteristic->setCallbacks(new CharCB());
  svc->start();
  BLEAdvertising *a = BLEDevice::getAdvertising();
  a->addServiceUUID(SERVICE_UUID); a->setScanResponse(true);
  BLEDevice::startAdvertising();
  Serial.println("Listo. Esperando telefono...");
}

void loop() { if (!deviceConnected) delay(100); else delay(10); }

void procesar(char c) {
  switch(c) {
    case 'L': case 'l': girarIzquierda(); break;
    case 'C': case 'c': avanzar(); break;
    case 'R': case 'r': girarDerecha(); break;
    case 'F': case 'f': avanzar(); break;
    case 'S': case 's': detener(); break;
    case 'X': case 'x': detener(); break;
  }
}
void avanzar() { digitalWrite(IN1,HIGH);digitalWrite(IN2,LOW);digitalWrite(IN3,HIGH);digitalWrite(IN4,LOW);analogWrite(ENA,velocidad);analogWrite(ENB,velocidad); }
void girarIzquierda() { digitalWrite(IN1,LOW);digitalWrite(IN2,LOW);digitalWrite(IN3,HIGH);digitalWrite(IN4,LOW);analogWrite(ENA,0);analogWrite(ENB,velocidad); }
void girarDerecha() { digitalWrite(IN1,HIGH);digitalWrite(IN2,LOW);digitalWrite(IN3,LOW);digitalWrite(IN4,LOW);analogWrite(ENA,velocidad);analogWrite(ENB,0); }
void detener() { digitalWrite(IN1,LOW);digitalWrite(IN2,LOW);digitalWrite(IN3,LOW);digitalWrite(IN4,LOW);analogWrite(ENA,0);analogWrite(ENB,0); }